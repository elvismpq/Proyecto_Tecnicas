package Clientes;

import Conector.Conector;
import Tarifas.Tarifas;
import java.awt.Dialog;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.JTable;

public class Interfaces extends javax.swing.JFrame {

    static ResultSet res;

    public Interfaces() throws SQLException {
        
        initComponents();
        MensajeBuscador.setVisible(false);
        MensajeBotonEliminar.setVisible(false);
        MensajeBotonModificar.setVisible(false);
        MensajeComboFiltros.setVisible(false);
        CargarDatosActivos();
        CargarDatosActivosEn();
        CargarDatosActivosP();
        CargarDatosDisponibleEq();
    }

    
    
    
    public Image getIconImage() {
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("imagenes/icono.png"));
        return retValue;
    }
/*Clientes*/
     public void CargarDatos() throws SQLException {
        DefaultTableModel modelo = (DefaultTableModel) ICTabla.getModel();
        modelo.setRowCount(0);
        res = Conector.Consulta("select CI,Nombre,Apellido,TipoTarifa,ValorTarifa,Celular,Telefono,Direccion,Control,Email,Observaciones from Clientes,Tarifa where Tarifa.IdTarifa=Clientes.IdTarifa");

        try {
            while (res.next()) {
                Vector v = new Vector();
                v.add(res.getString(1));
                v.add(res.getString(2));
                v.add(res.getString(3));
                v.add(res.getString(4));
                v.add(res.getDouble(5));
                v.add(res.getString(6));
                v.add(res.getString(7));
                v.add(res.getString(8));
                v.add(res.getString(9));
                v.add(res.getString(10));
                v.add(res.getString(11));
                modelo.addRow(v);
                ICTabla.setModel(modelo);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexion" + e.getMessage(), "Error de Conexion", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void CargarDatosEliminados() throws SQLException {
        DefaultTableModel modelo = (DefaultTableModel) ICTabla.getModel();
        modelo.setRowCount(0);
        res = Conector.Consulta("select CI,Nombre,Apellido,TipoTarifa,ValorTarifa,Celular,Telefono,Direccion,Control,Email,Observaciones from Clientes,Tarifa where Tarifa.IdTarifa=Clientes.IdTarifa and Estado='ELIMINADO'");

        try {
            while (res.next()) {
                Vector v = new Vector();
                v.add(res.getString(1));
                v.add(res.getString(2));
                v.add(res.getString(3));
                v.add(res.getString(4));
                v.add(res.getDouble(5));
                v.add(res.getString(6));
                v.add(res.getString(7));
                v.add(res.getString(8));
                v.add(res.getString(9));
                v.add(res.getString(10));
                v.add(res.getString(11));
                modelo.addRow(v);
                ICTabla.setModel(modelo);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexion" + e.getMessage(), "Error de Conexion", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void CargarDatosActivos() throws SQLException {
        DefaultTableModel modelo = (DefaultTableModel) ICTabla.getModel();
        modelo.setRowCount(0);
        res = Conector.Consulta("select CI,Nombre,Apellido,TipoTarifa,ValorTarifa,Celular,Telefono,Direccion,Control,Email,Observaciones from Clientes,Tarifa where Tarifa.IdTarifa=Clientes.IdTarifa and Estado='ACTIVO'");

        try {
            while (res.next()) {
                Vector v = new Vector();
                v.add(res.getString(1));
                v.add(res.getString(2));
                v.add(res.getString(3));
                v.add(res.getString(4));
                v.add(res.getDouble(5));
                v.add(res.getString(6));
                v.add(res.getString(7));
                v.add(res.getString(8));
                v.add(res.getString(9));
                v.add(res.getString(10));
                v.add(res.getString(11));
                modelo.addRow(v);
                ICTabla.setModel(modelo);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexiono" + e.getMessage(), "Error de Conexion", JOptionPane.ERROR_MESSAGE);
        }
    }
    /*Fin datos clientes*/
    /*Entrenadores*/
        public void CargarDatosEn() throws SQLException {
        DefaultTableModel modelo = (DefaultTableModel) IEtabla.getModel();
        modelo.setRowCount(0);
        res = Conector.Consulta("select CI,Nombres,Apellidos,Telefono,Celular,Direccion,Salario,email,Observaciones from Entrenadores");

        try {
            while (res.next()) {
                Vector v = new Vector();
                v.add(res.getString(1));
                v.add(res.getString(2));
                v.add(res.getString(3));
                v.add(res.getString(4));
                v.add(res.getString(5));
                v.add(res.getString(6));
                v.add(res.getDouble(7));
                v.add(res.getString(8));
                v.add(res.getString(9));
                modelo.addRow(v);
                IEtabla.setModel(modelo);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexion" + e.getMessage(), "Error de Conexion", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void CargarDatosEliminadosEn() throws SQLException {
        DefaultTableModel modelo = (DefaultTableModel) IEtabla.getModel();
        modelo.setRowCount(0);
        res = Conector.Consulta("select CI,Nombres,Apellidos,Telefono,Celular,Direccion,Salario,Email,Observaciones from Entrenadores where Estado='ELIMINADO'");
        try {
            while (res.next()) {
                Vector v = new Vector();
                v.add(res.getString(1));
                v.add(res.getString(2));
                v.add(res.getString(3));
                v.add(res.getString(4));
                v.add(res.getString(5));
                v.add(res.getString(6));
                v.add(res.getDouble(7));
                v.add(res.getString(8));
                v.add(res.getString(9));
                modelo.addRow(v);
                IEtabla.setModel(modelo);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexion" + e.getMessage(), "Error de Conexion", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void CargarDatosActivosEn() throws SQLException {
        
        DefaultTableModel modelo = (DefaultTableModel) IEtabla.getModel();
        modelo.setRowCount(0);
        res = Conector.Consulta("select CI,Nombres,Apellidos,Telefono,Celular,Direccion,Salario,email,Observaciones from Entrenadores where Estado='ACTIVO'");

        try {
            while (res.next()) {
                Vector v = new Vector();
                v.add(res.getString(1));
                v.add(res.getString(2));
                v.add(res.getString(3));
                v.add(res.getString(4));
                v.add(res.getString(5));
                v.add(res.getString(6));
                v.add(res.getDouble(7));
                v.add(res.getString(8));
                v.add(res.getString(9));
                modelo.addRow(v);
                IEtabla.setModel(modelo);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexion" + e.getMessage(), "Error de Conexion", JOptionPane.ERROR_MESSAGE);
        }
    }
    /*Fin de entrenadores*/
    /*Proveedores*/
        public void CargarDatosP() throws SQLException {
        DefaultTableModel modelo = (DefaultTableModel) IPtabla.getModel();
        modelo.setRowCount(0);
        res = Conector.Consulta("select RUC,Nombre,Telefono,Celular,Direccion,Producto,email,Observaciones from Proveedores");

        try {
            while (res.next()) {
                Vector v = new Vector();
                v.add(res.getString(1));
                v.add(res.getString(2));
                v.add(res.getString(3));
                v.add(res.getString(4));
                v.add(res.getString(5));
                v.add(res.getString(6));
                v.add(res.getString(7));
                v.add(res.getString(8));
                modelo.addRow(v);
                IPtabla.setModel(modelo);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexion" + e.getMessage(), "Error de Conexion", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void CargarDatosEliminadosP() throws SQLException {
        DefaultTableModel modelo = (DefaultTableModel) IPtabla.getModel();
        modelo.setRowCount(0);
        res = Conector.Consulta("select RUC,Nombre,Telefono,Celular,Direccion,Producto,email,Observaciones from Proveedores where Estado='ELIMINADO'");
        try {
            while (res.next()) {
                Vector v = new Vector();
                v.add(res.getString(1));
                v.add(res.getString(2));
                v.add(res.getString(3));
                v.add(res.getString(4));
                v.add(res.getString(5));
                v.add(res.getString(6));
                v.add(res.getString(7));
                v.add(res.getString(8));
                modelo.addRow(v);
                IPtabla.setModel(modelo);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexion" + e.getMessage(), "Error de Conexion", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void CargarDatosActivosP() throws SQLException {
        
        DefaultTableModel modelo = (DefaultTableModel) IPtabla.getModel();
        modelo.setRowCount(0);
        res = Conector.Consulta("select RUC,Nombre,Telefono,Celular,Direccion,Producto,email,Observaciones from Proveedores where Estado='ACTIVO'");

        try {
            while (res.next()) {
                Vector v = new Vector();
                v.add(res.getString(1));
                v.add(res.getString(2));
                v.add(res.getString(3));
                v.add(res.getString(4));
                v.add(res.getString(5));
                v.add(res.getString(6));
                v.add(res.getString(7));
                v.add(res.getString(8));
                modelo.addRow(v);
                IPtabla.setModel(modelo);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexion" + e.getMessage(), "Error de Conexion", JOptionPane.ERROR_MESSAGE);
        }
    }
    /*Fin de proveedores*/
    /*Equipamento*/
    public void CargarDatosEq() throws SQLException {
        DefaultTableModel modelo = (DefaultTableModel) IEqtabla.getModel();
        modelo.setRowCount(0);
        res = Conector.Consulta("select IdEquipamento,Nombre,Valor,Observaciones from Equipamento");

        try {
            while (res.next()) {
                Vector v = new Vector();
                v.add(res.getString(1));
                v.add(res.getString(2));
                v.add(res.getDouble(3));
                v.add(res.getString(4));
                modelo.addRow(v);
                IEqtabla.setModel(modelo);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexion" + e.getMessage(), "Error de Conexion", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void CargarDatosInactivosEq() throws SQLException {
        DefaultTableModel modelo = (DefaultTableModel) IEqtabla.getModel();
        modelo.setRowCount(0);
        res = Conector.Consulta("select IdEquipamento,Nombre,Valor,Observaciones from Equipamento where Estado='INACTIVO'");
        try {
            while (res.next()) {
                Vector v = new Vector();
                v.add(res.getString(1));
                v.add(res.getString(2));
                v.add(res.getDouble(3));
                v.add(res.getString(4));
                modelo.addRow(v);
                IEqtabla.setModel(modelo);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexion" + e.getMessage(), "Error de Conexion", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void CargarDatosDisponibleEq() throws SQLException {
        
        DefaultTableModel modelo = (DefaultTableModel) IEqtabla.getModel();
        modelo.setRowCount(0);
        res = Conector.Consulta("select IdEquipamento,Nombre,Valor,Observaciones from Equipamento where Estado='DISPONIBLE'");

        try {
            while (res.next()) {
                Vector v = new Vector();
                v.add(res.getString(1));
                v.add(res.getString(2));
                v.add(res.getDouble(3));
                v.add(res.getString(4));
                modelo.addRow(v);
                IEqtabla.setModel(modelo);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexion" + e.getMessage(), "Error de Conexion", JOptionPane.ERROR_MESSAGE);
        }
    }
    /*Fin de equipamento*/

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        PClientes = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        BAgregarClientes = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        ICTabla = new javax.swing.JTable();
        Filtro = new javax.swing.JComboBox<>();
        BEliminar = new javax.swing.JButton();
        BModificar = new javax.swing.JButton();
        MensajeBotonModificar = new javax.swing.JLabel();
        JTBuscar = new javax.swing.JTextField();
        MensajeComboFiltros = new javax.swing.JLabel();
        MensajeBotonEliminar = new javax.swing.JLabel();
        MensajeBuscador = new javax.swing.JLabel();
        Fondo1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        FiltroE = new javax.swing.JComboBox<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        IEtabla = new javax.swing.JTable();
        BModificarEn = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jTextField2 = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        FiltroP = new javax.swing.JComboBox<>();
        jScrollPane3 = new javax.swing.JScrollPane();
        IPtabla = new javax.swing.JTable();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        IEqtabla = new javax.swing.JTable();
        Modificar = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        FiltroEq = new javax.swing.JComboBox<>();
        jTextField3 = new javax.swing.JTextField();
        jPanel5 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        BAgregarClientes.setText("Agregar Cliente");
        BAgregarClientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BAgregarClientesActionPerformed(evt);
            }
        });
        jPanel1.add(BAgregarClientes, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 280, -1, -1));

        ICTabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "CI", "Nombre", "Apellido", "Tipo de Pago", "Valor", "Celular", "Telefono", "Direccion", "Control", "email", "Observaciones"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(ICTabla);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 1050, 190));

        Filtro.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Activos", "Eliminados", "Todos" }));
        Filtro.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                FiltroItemStateChanged(evt);
            }
        });
        Filtro.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                FiltroMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                FiltroMouseExited(evt);
            }
        });
        Filtro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FiltroActionPerformed(evt);
            }
        });
        jPanel1.add(Filtro, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 169, -1));

        BEliminar.setText("Eliminar");
        BEliminar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BEliminarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BEliminarMouseExited(evt);
            }
        });
        BEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BEliminarActionPerformed(evt);
            }
        });
        jPanel1.add(BEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 290, 97, -1));

        BModificar.setText("Modificar");
        BModificar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BModificarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BModificarMouseExited(evt);
            }
        });
        BModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BModificarActionPerformed(evt);
            }
        });
        jPanel1.add(BModificar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 290, 142, -1));

        MensajeBotonModificar.setText("Botón para modificar registro de un cliente ");
        jPanel1.add(MensajeBotonModificar, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 260, -1, -1));

        JTBuscar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                JTBuscarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                JTBuscarMouseExited(evt);
            }
        });
        JTBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                JTBuscarKeyReleased(evt);
            }
        });
        jPanel1.add(JTBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 30, 140, -1));

        MensajeComboFiltros.setText("Filtro de clientes por:");
        jPanel1.add(MensajeComboFiltros, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        MensajeBotonEliminar.setText("Botón para eliminar clientes del registro");
        jPanel1.add(MensajeBotonEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 260, -1, -1));

        MensajeBuscador.setText("Busqueda de clientes por nombre o apellido:");
        jPanel1.add(MensajeBuscador, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 30, -1, -1));

        Fondo1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/PantallaPri.jpg"))); // NOI18N
        jPanel1.add(Fondo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 0, -1, 320));

        PClientes.addTab("Clientes", jPanel1);

        FiltroE.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Activos", "Eliminados", "Todos" }));
        FiltroE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FiltroEActionPerformed(evt);
            }
        });

        IEtabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "CI", "Nombres", "Apellidos", "Telefono", "Celular", "Direccion", "Salario", "email", "Observaciones"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(IEtabla);

        BModificarEn.setText("Modificar");
        BModificarEn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BModificarEnActionPerformed(evt);
            }
        });

        jButton2.setText("Eliminar");

        jButton3.setText("Agregar Entrenador");

        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(BModificarEn)
                .addGap(80, 80, 80)
                .addComponent(jButton2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton3)
                .addGap(36, 36, 36))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 1036, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(FiltroE, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(55, 55, 55))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(36, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(FiltroE, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BModificarEn)
                    .addComponent(jButton2)
                    .addComponent(jButton3))
                .addContainerGap())
        );

        PClientes.addTab("Entrenadores", jPanel2);

        FiltroP.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Activos", "Eliminados", "Todos" }));
        FiltroP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FiltroPActionPerformed(evt);
            }
        });

        IPtabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "RUC", "Nombre", "Telefono", "Celular", "Direccion", "Producto", "email", "Observaciones"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, true, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane3.setViewportView(IPtabla);

        jButton4.setText("Modificar");

        jButton5.setText("Eliminar");

        jButton6.setText("Agregar Proveedores");

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(jButton4)
                .addGap(81, 81, 81)
                .addComponent(jButton5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 577, Short.MAX_VALUE)
                .addComponent(jButton6)
                .addGap(48, 48, 48))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3)
                .addContainerGap())
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(FiltroP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(62, 62, 62))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(33, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(FiltroP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton4)
                    .addComponent(jButton5)
                    .addComponent(jButton6))
                .addContainerGap())
        );

        PClientes.addTab("Proveedores", jPanel3);

        IEqtabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID Equipamento", "Nombre", "Valor", "Observaciones"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane4.setViewportView(IEqtabla);

        Modificar.setText("Modificar");

        jButton8.setText("Inactivo");

        jButton9.setText("Agregar Equipamento");

        FiltroEq.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Disponibles", "Inactivos", "Todos" }));
        FiltroEq.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FiltroEqActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addComponent(Modificar)
                .addGap(85, 85, 85)
                .addComponent(jButton8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 565, Short.MAX_VALUE)
                .addComponent(jButton9)
                .addGap(47, 47, 47))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jScrollPane4)
                        .addContainerGap())
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(FiltroEq, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(52, 52, 52))))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(FiltroEq, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 202, Short.MAX_VALUE)
                .addGap(23, 23, 23)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Modificar)
                    .addComponent(jButton8)
                    .addComponent(jButton9))
                .addContainerGap())
        );

        PClientes.addTab("Equipamento", jPanel4);

        jLabel1.setText("Ingresos totales:");

        jLabel2.setText("Saldos impagos:");

        jLabel3.setText("Saldos Pagados:");

        jLabel4.setText("jLabel4");

        jLabel5.setText("jLabel5");

        jLabel6.setText("jLabel6");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(193, 193, 193)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel1)
                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel3)
                        .addComponent(jLabel2)))
                .addGap(117, 117, 117)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6))
                .addContainerGap(613, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(53, 53, 53)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel4))
                .addGap(45, 45, 45)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel5))
                .addGap(39, 39, 39)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel6))
                .addContainerGap(142, Short.MAX_VALUE))
        );

        PClientes.addTab("Contable", jPanel5);

        jMenu1.setText("Inicio");

        jMenuItem1.setText("Tarifas");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Ayuda");
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(PClientes)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PClientes, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 357, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jCalendar1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jCalendar1MouseClicked
        //int seleccion = jCalendar1.
    }//GEN-LAST:event_jCalendar1MouseClicked

    private void JTBuscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JTBuscarKeyReleased
        buscar();
    }//GEN-LAST:event_JTBuscarKeyReleased

    private void JTBuscarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JTBuscarMouseExited
        MensajeBuscador.setVisible(false);
    }//GEN-LAST:event_JTBuscarMouseExited

    private void JTBuscarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JTBuscarMouseEntered
        MensajeBuscador.setVisible(true);
    }//GEN-LAST:event_JTBuscarMouseEntered

    private void BModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BModificarActionPerformed
  try {
            int filsel = ICTabla.getSelectedRow();
            String num = ICTabla.getValueAt(filsel, 0).toString();
            System.out.println(filsel);
            if (filsel == -1) {
                JOptionPane.showMessageDialog(null, "Debes seleccionar el cliente a modificar", "Advertencia", JOptionPane.WARNING_MESSAGE);
            } else {

                MClientes abrir;
                try {
                    abrir = new MClientes(num);
                    abrir.setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(Interfaces.class.getName()).log(Level.SEVERE, null, ex);

                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        

    }//GEN-LAST:event_BModificarActionPerformed

    private void BModificarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BModificarMouseExited
        MensajeBotonModificar.setVisible(false);
    }//GEN-LAST:event_BModificarMouseExited

    private void BModificarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BModificarMouseEntered
        MensajeBotonModificar.setVisible(true);
    }//GEN-LAST:event_BModificarMouseEntered

    private void BEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BEliminarActionPerformed

        Connection cn = Conector.getConexion();
        int filsel;
        int resp;

        try {
            filsel = ICTabla.getSelectedRow();
            if (filsel == -1) {
                JOptionPane.showMessageDialog(null, "Debes seleccionar el cliente a eliminar", "Advertencia", JOptionPane.WARNING_MESSAGE);
            } else {
                resp = JOptionPane.showConfirmDialog(null, "¿Esta seguro de eliminar este cliente?", "Eliminar", JOptionPane.YES_NO_OPTION);
                if (resp == JOptionPane.YES_OPTION) {

                    PreparedStatement pps = cn.prepareStatement("update Clientes set Estado='ELIMINADO' where ci=?");
                    pps.setString(1, ICTabla.getValueAt(filsel, 0).toString());
                    JOptionPane.showMessageDialog(null, "Cliente Eliminado");
                    int resp2 = pps.executeUpdate();
                    if (resp2 < 0) {
                        JOptionPane.showMessageDialog(null, "Error al ingresar");
                    }
                }
            }
            CargarDatosActivos();
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, "No se pudo eliminar el cliente");
        }
    }//GEN-LAST:event_BEliminarActionPerformed

    private void BEliminarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BEliminarMouseExited
        MensajeBotonEliminar.setVisible(false);
    }//GEN-LAST:event_BEliminarMouseExited

    private void BEliminarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BEliminarMouseEntered
        MensajeBotonEliminar.setVisible(true);
    }//GEN-LAST:event_BEliminarMouseEntered

    private void FiltroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FiltroActionPerformed

        if (Filtro.getSelectedItem().toString() == "Todos") {
            try {
                CargarDatos();
            } catch (SQLException ex) {
                Logger.getLogger(Interfaces.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if (Filtro.getSelectedItem().toString() == "Eliminados") {
            try {
                CargarDatosEliminados();
            } catch (SQLException ex) {
                Logger.getLogger(Interfaces.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if (Filtro.getSelectedItem().toString() == "Activos") {
            try {
                CargarDatosActivos();
            } catch (SQLException ex) {
                Logger.getLogger(Interfaces.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_FiltroActionPerformed

    private void FiltroMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_FiltroMouseExited
        MensajeComboFiltros.setVisible(false);
    }//GEN-LAST:event_FiltroMouseExited

    private void FiltroMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_FiltroMouseEntered
        MensajeComboFiltros.setVisible(true);
    }//GEN-LAST:event_FiltroMouseEntered

    private void FiltroItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_FiltroItemStateChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_FiltroItemStateChanged

    private void BAgregarClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BAgregarClientesActionPerformed

        AClientes abrir;
        try {
            abrir = new AClientes();
            abrir.setVisible(true);
        } catch (SQLException ex) {
            Logger.getLogger(Interfaces.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }//GEN-LAST:event_BAgregarClientesActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void FiltroEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FiltroEActionPerformed
        if (FiltroE.getSelectedItem().toString() == "Todos") {
            try {
                CargarDatosEn();
            } catch (SQLException ex) {
                Logger.getLogger(Interfaces.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if (FiltroE.getSelectedItem().toString() == "Eliminados") {
            try {
                CargarDatosEliminadosEn();
            } catch (SQLException ex) {
                Logger.getLogger(Interfaces.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if (FiltroE.getSelectedItem().toString() == "Activos") {
            try {
                CargarDatosActivosEn();
            } catch (SQLException ex) {
                Logger.getLogger(Interfaces.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_FiltroEActionPerformed

    private void FiltroPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FiltroPActionPerformed
        if (FiltroP.getSelectedItem().toString() == "Todos") {
            try {
                CargarDatosP();
            } catch (SQLException ex) {
                Logger.getLogger(Interfaces.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if (FiltroP.getSelectedItem().toString() == "Eliminados") {
            try {
                CargarDatosEliminadosP();
            } catch (SQLException ex) {
                Logger.getLogger(Interfaces.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if (FiltroP.getSelectedItem().toString() == "Activos") {
            try {
                CargarDatosActivosP();
            } catch (SQLException ex) {
                Logger.getLogger(Interfaces.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_FiltroPActionPerformed

    private void FiltroEqActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FiltroEqActionPerformed
        if (FiltroEq.getSelectedItem().toString() == "Todos") {
            try {
                CargarDatosEq();
            } catch (SQLException ex) {
                Logger.getLogger(Interfaces.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if (FiltroEq.getSelectedItem().toString() == "Inactivos") {
            try {
                CargarDatosInactivosEq();
            } catch (SQLException ex) {
                Logger.getLogger(Interfaces.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if (FiltroEq.getSelectedItem().toString() == "Disponibles") {
            try {
                CargarDatosDisponibleEq();
            } catch (SQLException ex) {
                Logger.getLogger(Interfaces.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_FiltroEqActionPerformed

    private void BModificarEnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BModificarEnActionPerformed
        try {
            int filsel = IEtabla.getSelectedRow();
            String num = IEtabla.getValueAt(filsel, 0).toString();
            if (filsel == -1) {
                JOptionPane.showMessageDialog(null, "Debes seleccionar el cliente a eliminar", "Advertencia", JOptionPane.WARNING_MESSAGE);
            } else {
                MEntrenadores abrir;
                abrir = new MEntrenadores(num);
                abrir.setVisible(true);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Seleccione el cliente a modificar");
        }
    }//GEN-LAST:event_BModificarEnActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
       Tarifas tar;
        try {
            tar= new Tarifas();
            tar.setVisible(true);
        } catch (SQLException ex) {
            Logger.getLogger(Interfaces.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    public static void main(String args[]) {
        
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Interfaces.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Interfaces.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Interfaces.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Interfaces.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new Interfaces().setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(Interfaces.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BAgregarClientes;
    private javax.swing.JButton BEliminar;
    private javax.swing.JButton BModificar;
    private javax.swing.JButton BModificarEn;
    private javax.swing.JComboBox<String> Filtro;
    private javax.swing.JComboBox<String> FiltroE;
    private javax.swing.JComboBox<String> FiltroEq;
    private javax.swing.JComboBox<String> FiltroP;
    private javax.swing.JLabel Fondo1;
    private javax.swing.JTable ICTabla;
    private javax.swing.JTable IEqtabla;
    private javax.swing.JTable IEtabla;
    private javax.swing.JTable IPtabla;
    private javax.swing.JTextField JTBuscar;
    private javax.swing.JLabel MensajeBotonEliminar;
    private javax.swing.JLabel MensajeBotonModificar;
    private javax.swing.JLabel MensajeBuscador;
    private javax.swing.JLabel MensajeComboFiltros;
    private javax.swing.JButton Modificar;
    private javax.swing.JTabbedPane PClientes;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    // End of variables declaration//GEN-END:variables

    private void buscar() {
        DefaultTableModel modelo = (DefaultTableModel) ICTabla.getModel();
        modelo.setRowCount(0);
        String buscar=JTBuscar.getText();
        res = Conector.Consulta("select CI,Nombre,Apellido from Clientes where Apellido like '"+buscar+"%'"+" or Nombre like '"+buscar+"%'");

        try {
            while (res.next()) {
                Vector v = new Vector();
                v.add(res.getString(1));
                v.add(res.getString(2));
                v.add(res.getString(3));
                modelo.addRow(v);
                ICTabla.setModel(modelo);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexion" + e.getMessage(), "Error de Conexion", JOptionPane.ERROR_MESSAGE);
        }
    }
}
