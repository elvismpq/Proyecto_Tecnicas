/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clientes;

import Conector.Conector;
import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import Clientes.Interfaces;
import static Clientes.Interfaces.res;
import javax.swing.JOptionPane;

public class AClientes extends javax.swing.JFrame {
String aux;
    Conector con = new Conector();
    Connection cn = con.getConexion();
    
    
    
    public AClientes() throws SQLException {
        initComponents();
        MesajeCI.setVisible(false);
        MesajeNombre.setVisible(false);
        MesajeApellido.setVisible(false);
        MensajeCelular.setVisible(false);
        MensajeEmail.setVisible(false);
        MensajeConvencional.setVisible(false);
        MensajeDireccion.setVisible(false);
        MensajeOb.setVisible(false);
        MensajePago.setVisible(false);
        MensajeTipoPago.setVisible(false);
        MensajeBotonGuardar.setVisible(false);
        MensajeBotonAtras.setVisible(false);
        CargarTarifas();
       
        this.setLocationRelativeTo(null);
    }
public void CargarTarifas() throws SQLException {
        
          res = Conector.Consulta("select TipoTarifa from Tarifa");
    try {
            while (res.next()) {
                this.ComTipoPago.addItem(res.getString(1));
                
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexion" + e.getMessage(), "Error de Conexion", JOptionPane.ERROR_MESSAGE);
        }      
          
    }
  public void CargarValor(String tip){
     res = Conector.Consulta("select VALORTARIFA,IDTARIFA from Tarifa where TIPOTARIFA='"+tip+"'");
      try { 
          while(res.next()){
                txtValor.setText(res.getString(1));
                aux=res.getString(2);
      }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexion" + e.getMessage(), "Error de Conexion", JOptionPane.ERROR_MESSAGE);
        }
     
     
    }

    

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        txtObservaciones = new javax.swing.JTextField();
        txtCI = new javax.swing.JTextField();
        txtnombre = new javax.swing.JTextField();
        txtapellido = new javax.swing.JTextField();
        txtCelular = new javax.swing.JTextField();
        txtdireccion = new javax.swing.JTextField();
        txtemail = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txtValor = new javax.swing.JTextField();
        txttelefono = new javax.swing.JTextField();
        Bnombre = new javax.swing.JButton();
        BGuardar = new javax.swing.JButton();
        MesajeCI = new javax.swing.JLabel();
        MesajeNombre = new javax.swing.JLabel();
        MesajeApellido = new javax.swing.JLabel();
        MensajeTipoPago = new javax.swing.JLabel();
        MensajePago = new javax.swing.JLabel();
        MensajeCelular = new javax.swing.JLabel();
        MensajeConvencional = new javax.swing.JLabel();
        MensajeDireccion = new javax.swing.JLabel();
        MensajeEmail = new javax.swing.JLabel();
        MensajeOb = new javax.swing.JLabel();
        MensajeBotonGuardar = new javax.swing.JLabel();
        MensajeBotonAtras = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txtControl = new javax.swing.JTextField();
        MensajeControl = new javax.swing.JLabel();
        ComTipoPago = new javax.swing.JComboBox<>();
        fondo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("CI");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 30, -1, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Nombre");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 80, -1, -1));

        jLabel3.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Apellido");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 130, -1, -1));

        jLabel4.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Tipo de pago");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 180, -1, -1));

        jLabel5.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Valor");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 180, -1, -1));

        jLabel6.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Celular");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 230, -1, -1));

        jLabel7.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Direccion");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 280, -1, -1));

        jLabel8.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Email");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 330, -1, -1));

        jLabel9.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Observaciones");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 370, -1, -1));

        txtObservaciones.setBackground(new java.awt.Color(204, 204, 204));
        txtObservaciones.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                txtObservacionesMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                txtObservacionesMouseExited(evt);
            }
        });
        txtObservaciones.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtObservacionesActionPerformed(evt);
            }
        });
        getContentPane().add(txtObservaciones, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 400, 540, 100));

        txtCI.setBackground(new java.awt.Color(204, 204, 204));
        txtCI.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        txtCI.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                txtCIMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                txtCIMouseExited(evt);
            }
        });
        txtCI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCIActionPerformed(evt);
            }
        });
        txtCI.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCIKeyTyped(evt);
            }
        });
        getContentPane().add(txtCI, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 30, 160, -1));

        txtnombre.setBackground(new java.awt.Color(204, 204, 204));
        txtnombre.setCaretColor(new java.awt.Color(255, 255, 255));
        txtnombre.setSelectionColor(new java.awt.Color(255, 255, 255));
        txtnombre.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                txtnombreMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                txtnombreMouseExited(evt);
            }
        });
        txtnombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnombreActionPerformed(evt);
            }
        });
        getContentPane().add(txtnombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 80, 400, -1));

        txtapellido.setBackground(new java.awt.Color(204, 204, 204));
        txtapellido.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                txtapellidoMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                txtapellidoMouseExited(evt);
            }
        });
        txtapellido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtapellidoActionPerformed(evt);
            }
        });
        getContentPane().add(txtapellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 130, 400, -1));

        txtCelular.setBackground(new java.awt.Color(204, 204, 204));
        txtCelular.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                txtCelularMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                txtCelularMouseExited(evt);
            }
        });
        txtCelular.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCelularKeyTyped(evt);
            }
        });
        getContentPane().add(txtCelular, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 230, 190, -1));

        txtdireccion.setBackground(new java.awt.Color(204, 204, 204));
        txtdireccion.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                txtdireccionMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                txtdireccionMouseExited(evt);
            }
        });
        getContentPane().add(txtdireccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 280, 410, -1));

        txtemail.setBackground(new java.awt.Color(204, 204, 204));
        txtemail.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                txtemailMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                txtemailMouseExited(evt);
            }
        });
        getContentPane().add(txtemail, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 330, 210, -1));

        jLabel10.setFont(new java.awt.Font("Arial Black", 1, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Telefono");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 230, -1, -1));

        txtValor.setBackground(new java.awt.Color(204, 204, 204));
        txtValor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                txtValorMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                txtValorMouseExited(evt);
            }
        });
        getContentPane().add(txtValor, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 180, 140, -1));

        txttelefono.setBackground(new java.awt.Color(204, 204, 204));
        txttelefono.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                txttelefonoMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                txttelefonoMouseExited(evt);
            }
        });
        txttelefono.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txttelefonoActionPerformed(evt);
            }
        });
        txttelefono.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txttelefonoKeyTyped(evt);
            }
        });
        getContentPane().add(txttelefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 230, 140, -1));

        Bnombre.setText("ATRAS");
        Bnombre.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BnombreMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BnombreMouseExited(evt);
            }
        });
        Bnombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BnombreActionPerformed(evt);
            }
        });
        getContentPane().add(Bnombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 520, -1, -1));

        BGuardar.setText("GUARDAR");
        BGuardar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BGuardarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BGuardarMouseExited(evt);
            }
        });
        BGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BGuardarActionPerformed(evt);
            }
        });
        getContentPane().add(BGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 520, -1, -1));

        MesajeCI.setForeground(new java.awt.Color(255, 255, 255));
        MesajeCI.setText("Ingrese la cédula del cliente:  ");
        getContentPane().add(MesajeCI, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 10, -1, -1));

        MesajeNombre.setForeground(new java.awt.Color(255, 255, 255));
        MesajeNombre.setText("Ingresar nombre del cliente:");
        getContentPane().add(MesajeNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 60, 160, 20));

        MesajeApellido.setForeground(new java.awt.Color(255, 255, 255));
        MesajeApellido.setText("Ingresar Apellido del cliente:");
        getContentPane().add(MesajeApellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 110, -1, -1));

        MensajeTipoPago.setForeground(new java.awt.Color(255, 255, 255));
        MensajeTipoPago.setText("Ingresar el tipo de pago: ");
        getContentPane().add(MensajeTipoPago, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 160, -1, -1));

        MensajePago.setForeground(new java.awt.Color(255, 255, 255));
        MensajePago.setText("Ingresar el valor del pago:");
        getContentPane().add(MensajePago, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 160, -1, -1));

        MensajeCelular.setForeground(new java.awt.Color(255, 255, 255));
        MensajeCelular.setText("Ingresar el número  de celular del cliente:");
        getContentPane().add(MensajeCelular, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 210, -1, -1));

        MensajeConvencional.setForeground(new java.awt.Color(255, 255, 255));
        MensajeConvencional.setText("Ingresar Teléfono convencional del cliente ");
        getContentPane().add(MensajeConvencional, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 210, -1, -1));

        MensajeDireccion.setForeground(new java.awt.Color(255, 255, 255));
        MensajeDireccion.setText("Ingresar dirección del cliente:");
        getContentPane().add(MensajeDireccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 260, -1, -1));

        MensajeEmail.setForeground(new java.awt.Color(255, 255, 255));
        MensajeEmail.setText("Ingresar el Email:");
        getContentPane().add(MensajeEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 310, 160, -1));

        MensajeOb.setForeground(new java.awt.Color(255, 255, 255));
        MensajeOb.setText("Ingresar Observaciones adicionales del cliente:");
        getContentPane().add(MensajeOb, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 370, -1, -1));

        MensajeBotonGuardar.setForeground(new java.awt.Color(255, 255, 255));
        MensajeBotonGuardar.setText("Botón para guardar cambios");
        getContentPane().add(MensajeBotonGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 500, -1, -1));

        MensajeBotonAtras.setForeground(new java.awt.Color(255, 255, 255));
        MensajeBotonAtras.setText("Botón para regresar al menú de Clientes");
        getContentPane().add(MensajeBotonAtras, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 500, -1, -1));

        jLabel11.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Control");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 330, -1, -1));

        txtControl.setBackground(new java.awt.Color(204, 204, 204));
        txtControl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                txtControlMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                txtControlMouseExited(evt);
            }
        });
        getContentPane().add(txtControl, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 330, 150, -1));

        MensajeControl.setForeground(new java.awt.Color(255, 255, 255));
        MensajeControl.setText("Ingresar el tipo de control:");
        getContentPane().add(MensajeControl, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 310, 160, -1));

        ComTipoPago.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione tipo..." }));
        ComTipoPago.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComTipoPagoActionPerformed(evt);
            }
        });
        getContentPane().add(ComTipoPago, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 180, 150, -1));

        fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/5.jpg"))); // NOI18N
        getContentPane().add(fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 670, 550));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtObservacionesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtObservacionesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtObservacionesActionPerformed

    private void txtnombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtnombreActionPerformed

    private void txttelefonoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txttelefonoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txttelefonoActionPerformed

    private void txtapellidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtapellidoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtapellidoActionPerformed

    private void txtCIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCIActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCIActionPerformed

    private void BnombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BnombreActionPerformed
        this.dispose();
    }//GEN-LAST:event_BnombreActionPerformed

    private void BGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BGuardarActionPerformed
                // TODO add your handling code here:
       if(ComTipoPago.getSelectedItem().toString().equals("Seleccione tipo...")){
              JOptionPane.showMessageDialog(null, "Debes seleccionar una tarifa", "Advertencia", JOptionPane.WARNING_MESSAGE);
         }else{
        try {
            
            PreparedStatement pps = cn.prepareStatement("INSERT INTO Clientes(CI,Nombre,Apellido,Celular,Telefono,Direccion,Control,Estado,Email,Observaciones,IdTarifa) VALUES(?,?,?,?,?,?,?,?,?,?,?)");
            pps.setString(1, txtCI.getText());
            pps.setString(2, txtnombre.getText());
            pps.setString(3, txtapellido.getText());
            pps.setString(4, txtCelular.getText());
            pps.setString(5, txttelefono.getText());
            pps.setString(6, txtdireccion.getText());
            pps.setString(7, txtemail.getText());
            pps.setString(8, "ACTIVO");
            pps.setString(9, txtemail.getText());
            pps.setString(10, txtObservaciones.getText());
            pps.setString(11, aux);
            JOptionPane.showMessageDialog(null, "Datos Guardados");
            int resp = pps.executeUpdate();
            if (resp < 0) {
                JOptionPane.showMessageDialog(null, "Error al ingresar");
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        this.dispose();
         }
        
    }//GEN-LAST:event_BGuardarActionPerformed


//Inicio de eventos para control de funcionalidad 
    private void txtCIMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtCIMouseEntered
        MesajeCI.setVisible(true);
    }//GEN-LAST:event_txtCIMouseEntered

    private void txtCIMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtCIMouseExited
        MesajeCI.setVisible(false);
    }//GEN-LAST:event_txtCIMouseExited

    private void txtnombreMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtnombreMouseEntered
        MesajeNombre.setVisible(true);
    }//GEN-LAST:event_txtnombreMouseEntered

    private void txtapellidoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtapellidoMouseEntered
        MesajeApellido.setVisible(true);
    }//GEN-LAST:event_txtapellidoMouseEntered

    private void txtValorMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtValorMouseExited
        MensajePago.setVisible(false);
    }//GEN-LAST:event_txtValorMouseExited

    private void txtCelularMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtCelularMouseExited
        MensajeCelular.setVisible(false);
    }//GEN-LAST:event_txtCelularMouseExited

    private void txttelefonoMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txttelefonoMouseExited
        MensajeConvencional.setVisible(false);
    }//GEN-LAST:event_txttelefonoMouseExited

    private void txtdireccionMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtdireccionMouseExited
        MensajeDireccion.setVisible(false);
    }//GEN-LAST:event_txtdireccionMouseExited

    private void txtemailMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtemailMouseExited
        MensajeEmail.setVisible(false);
    }//GEN-LAST:event_txtemailMouseExited

    private void txtObservacionesMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtObservacionesMouseExited
        MensajeOb.setVisible(false);
    }//GEN-LAST:event_txtObservacionesMouseExited

    private void txtnombreMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtnombreMouseExited
        MesajeNombre.setVisible(false);
    }//GEN-LAST:event_txtnombreMouseExited

    private void txtapellidoMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtapellidoMouseExited
        MesajeApellido.setVisible(false);
    }//GEN-LAST:event_txtapellidoMouseExited

    private void txtValorMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtValorMouseEntered
        MensajePago.setVisible(true);
    }//GEN-LAST:event_txtValorMouseEntered

    private void txtCelularMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtCelularMouseEntered
        MensajeCelular.setVisible(true);
    }//GEN-LAST:event_txtCelularMouseEntered

    private void txttelefonoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txttelefonoMouseEntered
        MensajeConvencional.setVisible(true);
    }//GEN-LAST:event_txttelefonoMouseEntered

    private void txtdireccionMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtdireccionMouseEntered
        MensajeDireccion.setVisible(true);
    }//GEN-LAST:event_txtdireccionMouseEntered

    private void txtemailMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtemailMouseEntered
        MensajeEmail.setVisible(true);
    }//GEN-LAST:event_txtemailMouseEntered

    private void txtObservacionesMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtObservacionesMouseEntered
        MensajeOb.setVisible(true);
    }//GEN-LAST:event_txtObservacionesMouseEntered

    private void BGuardarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BGuardarMouseEntered
        MensajeBotonGuardar.setVisible(true);
    }//GEN-LAST:event_BGuardarMouseEntered

    private void BGuardarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BGuardarMouseExited
        MensajeBotonGuardar.setVisible(false);
    }//GEN-LAST:event_BGuardarMouseExited

    private void BnombreMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BnombreMouseEntered
        MensajeBotonAtras.setVisible(true);
    }//GEN-LAST:event_BnombreMouseEntered

    private void BnombreMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BnombreMouseExited
        MensajeBotonAtras.setVisible(false);
    }//GEN-LAST:event_BnombreMouseExited

    private void txtCIKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCIKeyTyped
        char  c= evt.getKeyChar();
        int numerosCaracteres =10;
        if(c<'0' || c>'9'){
            evt.consume();
        }
        if(txtCI.getText().length()>=numerosCaracteres){
            evt.consume();
            JOptionPane.showMessageDialog(rootPane, "Solo 10 caracteres");
        }
    }//GEN-LAST:event_txtCIKeyTyped

    private void txtCelularKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCelularKeyTyped
        // TODO add your handling code here:
        char  c= evt.getKeyChar();
        int numerosCaracteres =10;
        if(c<'0' || c>'9'){
            evt.consume();
        }
        if(txtCelular.getText().length()>=numerosCaracteres){
            evt.consume();
            JOptionPane.showMessageDialog(rootPane, "Solo 10 caracteres");
        }
    }//GEN-LAST:event_txtCelularKeyTyped

    private void txttelefonoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txttelefonoKeyTyped
        // TODO add your handling code here:
        char  c= evt.getKeyChar();
        if(c<'0' || c>'9'){
            evt.consume();
        }
    }//GEN-LAST:event_txttelefonoKeyTyped

    private void txtControlMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtControlMouseEntered
        MensajeControl.setVisible(true);
    }//GEN-LAST:event_txtControlMouseEntered

    private void txtControlMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtControlMouseExited
        MensajeControl.setVisible(false);
    }//GEN-LAST:event_txtControlMouseExited

    private void ComTipoPagoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComTipoPagoActionPerformed

        CargarValor(ComTipoPago.getSelectedItem().toString());

    }//GEN-LAST:event_ComTipoPagoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new AClientes().setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(AClientes.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BGuardar;
    private javax.swing.JButton Bnombre;
    private javax.swing.JComboBox<String> ComTipoPago;
    private javax.swing.JLabel MensajeBotonAtras;
    private javax.swing.JLabel MensajeBotonGuardar;
    private javax.swing.JLabel MensajeCelular;
    private javax.swing.JLabel MensajeControl;
    private javax.swing.JLabel MensajeConvencional;
    private javax.swing.JLabel MensajeDireccion;
    private javax.swing.JLabel MensajeEmail;
    private javax.swing.JLabel MensajeOb;
    private javax.swing.JLabel MensajePago;
    private javax.swing.JLabel MensajeTipoPago;
    private javax.swing.JLabel MesajeApellido;
    private javax.swing.JLabel MesajeCI;
    private javax.swing.JLabel MesajeNombre;
    private javax.swing.JLabel fondo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField txtCI;
    private javax.swing.JTextField txtCelular;
    private javax.swing.JTextField txtControl;
    private javax.swing.JTextField txtObservaciones;
    private javax.swing.JTextField txtValor;
    private javax.swing.JTextField txtapellido;
    private javax.swing.JTextField txtdireccion;
    private javax.swing.JTextField txtemail;
    private javax.swing.JTextField txtnombre;
    private javax.swing.JTextField txttelefono;
    // End of variables declaration//GEN-END:variables

    
}
