
package Clientes;

import static Clientes.Interfaces.res;
import Conector.Conector;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class MClientes extends javax.swing.JFrame {

    
    Conector con = new Conector();
    Connection cn = con.getConexion();

    public MClientes(String num) throws SQLException {
        initComponents();
        CargarDatosCI(num);
        MesajeCI.setVisible(false);
        MesajeNombre.setVisible(false);
        MesajeApellido.setVisible(false);
        MensajeCelular.setVisible(false);
        MensajeControl.setVisible(false);
        MensajeConvencional.setVisible(false);
        MensajeDireccion.setVisible(false);
        MensajeOb.setVisible(false);
        MensajePago.setVisible(false);
        MensajeTipoPago.setVisible(false);
        MensajeBotonGuardar.setVisible(false);
        MensajeBotonAtras.setVisible(false);
        this.setLocationRelativeTo(null);
        
       
    }
   
    

    public void CargarDatosCI(String num) throws SQLException {
        res = Conector.Consulta("select CI,Nombre,Apellido,TipodePago,Celular,Telefono,Direccion,Control,Observaciones from Clientes where CI='" + num + "'");
        try {
            while (res.next()) {
                this.txtCI.setText(res.getString(1));
                this.txtNombre.setText(res.getString(2));
                this.txtApellido.setText(res.getString(3));
                this.txtTipoDePago.setText(res.getString(4));
                this.txtValor.setText(res.getString(5));
                this.txtCelular.setText(res.getString(6));
                this.txtTelefono.setText(res.getString(7));
                this.txtDireccion.setText(res.getString(8));
                this.txtControl.setText(res.getString(9));
               
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexion" + e.getMessage(), "Error de Conexion", JOptionPane.ERROR_MESSAGE);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txtCI = new javax.swing.JTextField();
        txtNombre = new javax.swing.JTextField();
        txtApellido = new javax.swing.JTextField();
        txtTipoDePago = new javax.swing.JTextField();
        txtCelular = new javax.swing.JTextField();
        txtDireccion = new javax.swing.JTextField();
        txtControl = new javax.swing.JTextField();
        txtObservaciones = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txtValor = new javax.swing.JTextField();
        txtTelefono = new javax.swing.JTextField();
        BGuardar = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        MesajeCI = new javax.swing.JLabel();
        MesajeNombre = new javax.swing.JLabel();
        MesajeApellido = new javax.swing.JLabel();
        MensajeTipoPago = new javax.swing.JLabel();
        MensajePago = new javax.swing.JLabel();
        MensajeConvencional = new javax.swing.JLabel();
        MensajeCelular = new javax.swing.JLabel();
        MensajeDireccion = new javax.swing.JLabel();
        MensajeControl = new javax.swing.JLabel();
        MensajeOb = new javax.swing.JLabel();
        MensajeBotonGuardar = new javax.swing.JLabel();
        MensajeBotonAtras = new javax.swing.JLabel();
        fondo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("CI");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 18, -1, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Nombre");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 66, -1, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Apellido");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 110, -1, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Tipo de Pago");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 159, -1, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Celular");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 204, -1, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Dirección");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 250, -1, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Control");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 300, -1, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Observaciones");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 343, -1, -1));

        txtCI.setEditable(false);
        txtCI.setBackground(new java.awt.Color(204, 204, 204));
        txtCI.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        txtCI.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                txtCIMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                txtCIMouseExited(evt);
            }
        });
        getContentPane().add(txtCI, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 20, 140, -1));

        txtNombre.setBackground(new java.awt.Color(204, 204, 204));
        txtNombre.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        txtNombre.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                txtNombreMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                txtNombreMouseExited(evt);
            }
        });
        txtNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreActionPerformed(evt);
            }
        });
        getContentPane().add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(135, 63, 360, -1));

        txtApellido.setBackground(new java.awt.Color(204, 204, 204));
        txtApellido.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        txtApellido.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                txtApellidoMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                txtApellidoMouseExited(evt);
            }
        });
        txtApellido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtApellidoActionPerformed(evt);
            }
        });
        getContentPane().add(txtApellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(135, 107, 360, -1));

        txtTipoDePago.setBackground(new java.awt.Color(204, 204, 204));
        txtTipoDePago.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        txtTipoDePago.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                txtTipoDePagoMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                txtTipoDePagoMouseExited(evt);
            }
        });
        getContentPane().add(txtTipoDePago, new org.netbeans.lib.awtextra.AbsoluteConstraints(135, 156, 140, -1));

        txtCelular.setBackground(new java.awt.Color(204, 204, 204));
        txtCelular.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        txtCelular.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                txtCelularMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                txtCelularMouseExited(evt);
            }
        });
        txtCelular.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCelularKeyTyped(evt);
            }
        });
        getContentPane().add(txtCelular, new org.netbeans.lib.awtextra.AbsoluteConstraints(135, 201, 140, -1));

        txtDireccion.setBackground(new java.awt.Color(204, 204, 204));
        txtDireccion.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        txtDireccion.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                txtDireccionMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                txtDireccionMouseExited(evt);
            }
        });
        getContentPane().add(txtDireccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(135, 247, 360, -1));

        txtControl.setBackground(new java.awt.Color(204, 204, 204));
        txtControl.setFont(new java.awt.Font("Arial Black", 1, 12)); // NOI18N
        txtControl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                txtControlMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                txtControlMouseExited(evt);
            }
        });
        getContentPane().add(txtControl, new org.netbeans.lib.awtextra.AbsoluteConstraints(135, 297, 140, -1));

        txtObservaciones.setBackground(new java.awt.Color(204, 204, 204));
        txtObservaciones.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        txtObservaciones.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                txtObservacionesMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                txtObservacionesMouseExited(evt);
            }
        });
        getContentPane().add(txtObservaciones, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 380, 628, 105));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Valor");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 160, -1, -1));

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Teléfono");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 200, -1, -1));

        txtValor.setBackground(new java.awt.Color(204, 204, 204));
        txtValor.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txtValor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                txtValorMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                txtValorMouseExited(evt);
            }
        });
        txtValor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtValorActionPerformed(evt);
            }
        });
        getContentPane().add(txtValor, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 160, 140, -1));

        txtTelefono.setBackground(new java.awt.Color(204, 204, 204));
        txtTelefono.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        txtTelefono.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                txtTelefonoMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                txtTelefonoMouseExited(evt);
            }
        });
        txtTelefono.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtTelefonoKeyTyped(evt);
            }
        });
        getContentPane().add(txtTelefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 200, 140, -1));

        BGuardar.setBackground(new java.awt.Color(204, 204, 204));
        BGuardar.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        BGuardar.setText("Guardar");
        BGuardar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BGuardarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BGuardarMouseExited(evt);
            }
        });
        BGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BGuardarActionPerformed(evt);
            }
        });
        getContentPane().add(BGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(215, 514, -1, -1));

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton2.setText("Atras");
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton2MouseExited(evt);
            }
        });
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(399, 514, -1, -1));

        MesajeCI.setForeground(new java.awt.Color(255, 255, 255));
        MesajeCI.setText("Ingrese la cédula del cliente:  ");
        getContentPane().add(MesajeCI, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 0, -1, -1));

        MesajeNombre.setForeground(new java.awt.Color(255, 255, 255));
        MesajeNombre.setText("Ingresar nombre del cliente:");
        getContentPane().add(MesajeNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 40, 160, 20));

        MesajeApellido.setForeground(new java.awt.Color(255, 255, 255));
        MesajeApellido.setText("Ingresar Apellido del cliente:");
        getContentPane().add(MesajeApellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 90, -1, -1));

        MensajeTipoPago.setForeground(new java.awt.Color(255, 255, 255));
        MensajeTipoPago.setText("Ingresar el tipo de pago: ");
        getContentPane().add(MensajeTipoPago, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 140, -1, -1));

        MensajePago.setForeground(new java.awt.Color(255, 255, 255));
        MensajePago.setText("Ingresar el valor del pago:");
        getContentPane().add(MensajePago, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 140, -1, -1));

        MensajeConvencional.setForeground(new java.awt.Color(255, 255, 255));
        MensajeConvencional.setText("Ingresar Teléfono convencional del cliente ");
        getContentPane().add(MensajeConvencional, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 180, -1, -1));

        MensajeCelular.setForeground(new java.awt.Color(255, 255, 255));
        MensajeCelular.setText("Ingresar el número  de celular del cliente:");
        getContentPane().add(MensajeCelular, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 180, -1, -1));

        MensajeDireccion.setForeground(new java.awt.Color(255, 255, 255));
        MensajeDireccion.setText("Ingresar dirección del cliente:");
        getContentPane().add(MensajeDireccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 230, -1, -1));

        MensajeControl.setForeground(new java.awt.Color(255, 255, 255));
        MensajeControl.setText("Ingresar el tipo de control:");
        getContentPane().add(MensajeControl, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 280, 160, -1));

        MensajeOb.setForeground(new java.awt.Color(255, 255, 255));
        MensajeOb.setText("Ingresar Observaciones adicionales del cliente:");
        getContentPane().add(MensajeOb, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 350, -1, -1));

        MensajeBotonGuardar.setForeground(new java.awt.Color(255, 255, 255));
        MensajeBotonGuardar.setText("Botón para guardar cambios");
        getContentPane().add(MensajeBotonGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 490, -1, -1));

        MensajeBotonAtras.setForeground(new java.awt.Color(255, 255, 255));
        MensajeBotonAtras.setText("Botón para regresar al menú de Clientes");
        getContentPane().add(MensajeBotonAtras, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 490, -1, -1));

        fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/5.jpg"))); // NOI18N
        getContentPane().add(fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -150, 700, 740));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtValorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtValorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtValorActionPerformed

    private void txtApellidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtApellidoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtApellidoActionPerformed

    private void BGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BGuardarActionPerformed
        try {

            PreparedStatement pps = cn.prepareStatement("update Clientes set CI=?,Nombre=?,Apellido=?,TipodePago=?,Valor=?,Celular=?,Telefono=?,Direccion=?,Control=?,Observaciones=? where CI=?");
            pps.setString(1, txtCI.getText());
            pps.setString(2, txtNombre.getText());
            pps.setString(3, txtApellido.getText());
            pps.setString(4, txtTipoDePago.getText());
            pps.setString(5, txtValor.getText());
            pps.setString(6, txtCelular.getText());
            pps.setString(7, txtTelefono.getText());
            pps.setString(8, txtDireccion.getText());
            pps.setString(9, txtControl.getText());
            pps.setString(10, txtObservaciones.getText());
            pps.setString(11, txtCI.getText());
            JOptionPane.showMessageDialog(null, "Datos Guardados");
            int res = pps.executeUpdate();
            if (res < 0) {
                JOptionPane.showMessageDialog(null, "Error al ingresar");
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        this.dispose();
    }//GEN-LAST:event_BGuardarActionPerformed

    private void txtNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreActionPerformed

    }//GEN-LAST:event_txtNombreActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void txtCIMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtCIMouseEntered
        MesajeCI.setVisible(true);
    }//GEN-LAST:event_txtCIMouseEntered

    private void txtCIMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtCIMouseExited
        MesajeCI.setVisible(false);
        
    }//GEN-LAST:event_txtCIMouseExited

    private void txtNombreMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtNombreMouseEntered

        MesajeNombre.setVisible(true);
    }//GEN-LAST:event_txtNombreMouseEntered

    private void txtNombreMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtNombreMouseExited
        
        MesajeNombre.setVisible(false);
    }//GEN-LAST:event_txtNombreMouseExited

    private void txtApellidoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtApellidoMouseEntered
 
        MesajeApellido.setVisible(true);

    }//GEN-LAST:event_txtApellidoMouseEntered

    private void txtApellidoMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtApellidoMouseExited

        MesajeApellido.setVisible(false);
    }//GEN-LAST:event_txtApellidoMouseExited

    private void txtTipoDePagoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtTipoDePagoMouseEntered

        MensajeTipoPago.setVisible(true);
 
    }//GEN-LAST:event_txtTipoDePagoMouseEntered

    private void txtTipoDePagoMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtTipoDePagoMouseExited

        MensajeTipoPago.setVisible(false);

    }//GEN-LAST:event_txtTipoDePagoMouseExited

    private void txtValorMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtValorMouseEntered

        MensajePago.setVisible(true);
 
    }//GEN-LAST:event_txtValorMouseEntered

    private void txtValorMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtValorMouseExited
 
        MensajePago.setVisible(false);
      
    }//GEN-LAST:event_txtValorMouseExited

    private void txtCelularMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtCelularMouseEntered

        MensajeCelular.setVisible(true);

    }//GEN-LAST:event_txtCelularMouseEntered

    private void txtCelularMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtCelularMouseExited
        MensajeCelular.setVisible(false);
    }//GEN-LAST:event_txtCelularMouseExited

    private void txtTelefonoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtTelefonoMouseEntered
        MensajeConvencional.setVisible(true);    
    }//GEN-LAST:event_txtTelefonoMouseEntered

    private void txtTelefonoMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtTelefonoMouseExited

        MensajeConvencional.setVisible(false);
    }//GEN-LAST:event_txtTelefonoMouseExited

    private void txtDireccionMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtDireccionMouseEntered

        MensajeDireccion.setVisible(true);
    }//GEN-LAST:event_txtDireccionMouseEntered

    private void txtDireccionMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtDireccionMouseExited

        MensajeDireccion.setVisible(false);
    }//GEN-LAST:event_txtDireccionMouseExited

    private void txtControlMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtControlMouseEntered
 
        MensajeControl.setVisible(true);
    }//GEN-LAST:event_txtControlMouseEntered

    private void txtControlMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtControlMouseExited
 
        MensajeControl.setVisible(false);
    }//GEN-LAST:event_txtControlMouseExited

    private void txtObservacionesMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtObservacionesMouseEntered
        MensajeOb.setVisible(true);
    }//GEN-LAST:event_txtObservacionesMouseEntered

    private void txtObservacionesMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtObservacionesMouseExited
        MensajeOb.setVisible(false);
    }//GEN-LAST:event_txtObservacionesMouseExited

    private void BGuardarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BGuardarMouseEntered

        MensajeBotonGuardar.setVisible(true);
 
    }//GEN-LAST:event_BGuardarMouseEntered

    private void BGuardarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BGuardarMouseExited

        MensajeBotonGuardar.setVisible(false);
    }//GEN-LAST:event_BGuardarMouseExited

    private void jButton2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseEntered
 
        MensajeBotonAtras.setVisible(true);
    }//GEN-LAST:event_jButton2MouseEntered

    private void jButton2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseExited
        MensajeBotonAtras.setVisible(false);
    }//GEN-LAST:event_jButton2MouseExited

    private void txtCelularKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCelularKeyTyped
        // TODO add your handling code here:
        char  c= evt.getKeyChar();
        int numerosCaracteres =10;
        if(c<'0' || c>'9'){
            evt.consume();
        }
        if(txtCelular.getText().length()>=numerosCaracteres){
            evt.consume();
            JOptionPane.showMessageDialog(rootPane, "Solo 10 caracteres");
        }
    }//GEN-LAST:event_txtCelularKeyTyped

    private void txtTelefonoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTelefonoKeyTyped
        // TODO add your handling code here:
        char  c= evt.getKeyChar();
        if(c<'0' || c>'9'){
            evt.consume();
        }
    }//GEN-LAST:event_txtTelefonoKeyTyped

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new MClientes("1").setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(MClientes.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BGuardar;
    private javax.swing.JLabel MensajeBotonAtras;
    private javax.swing.JLabel MensajeBotonGuardar;
    private javax.swing.JLabel MensajeCelular;
    private javax.swing.JLabel MensajeControl;
    private javax.swing.JLabel MensajeConvencional;
    private javax.swing.JLabel MensajeDireccion;
    private javax.swing.JLabel MensajeOb;
    private javax.swing.JLabel MensajePago;
    private javax.swing.JLabel MensajeTipoPago;
    private javax.swing.JLabel MesajeApellido;
    private javax.swing.JLabel MesajeCI;
    private javax.swing.JLabel MesajeNombre;
    private javax.swing.JLabel fondo;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField txtApellido;
    private javax.swing.JTextField txtCI;
    private javax.swing.JTextField txtCelular;
    private javax.swing.JTextField txtControl;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtObservaciones;
    private javax.swing.JTextField txtTelefono;
    private javax.swing.JTextField txtTipoDePago;
    private javax.swing.JTextField txtValor;
    // End of variables declaration//GEN-END:variables
}
