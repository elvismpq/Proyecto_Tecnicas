package Clientes;

import Conector.Conector;
import java.awt.Dialog;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.awt.Image;
import java.awt.Toolkit;

public class Interfaces extends javax.swing.JFrame {

    static ResultSet res;

    public Interfaces() throws SQLException {
        System.out.println("Interfaces");
        initComponents();
        CargarDatosActivos();
    }
    public Image getIconImage() {
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("imagenes/icono.png"));
        return retValue;
    }

    public void CargarDatos() throws SQLException {
        System.out.println("Cargardatos");
        DefaultTableModel modelo = (DefaultTableModel) ICTabla.getModel();
        modelo.setRowCount(0);
        res = Conector.Consulta("select CI,Nombre,Apellido,TipodePago,Valor,Celular,Telefono,Direccion,Control,Observaciones from Clientes");

        try {
            while (res.next()) {
                Vector v = new Vector();
                v.add(res.getString(1));
                v.add(res.getString(2));
                v.add(res.getString(3));
                v.add(res.getString(4));
                v.add(res.getDouble(5));
                v.add(res.getString(6));
                v.add(res.getString(7));
                v.add(res.getString(8));
                v.add(res.getString(9));
                v.add(res.getString(10));
                modelo.addRow(v);
                ICTabla.setModel(modelo);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexion" + e.getMessage(), "Error de Conexion", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void CargarDatosEliminados() throws SQLException {
        System.out.println("eliminar datos");
        DefaultTableModel modelo = (DefaultTableModel) ICTabla.getModel();
        modelo.setRowCount(0);
        res = Conector.Consulta("select CI,Nombre,Apellido,TipodePago,Valor,Celular,Telefono,Direccion,Control,Observaciones from Clientes where Estado='ELIMINADO'");

        try {
            while (res.next()) {
                Vector v = new Vector();
                v.add(res.getString(1));
                v.add(res.getString(2));
                v.add(res.getString(3));
                v.add(res.getString(4));
                v.add(res.getDouble(5));
                v.add(res.getString(6));
                v.add(res.getString(7));
                v.add(res.getString(8));
                v.add(res.getString(9));
                v.add(res.getString(10));
                modelo.addRow(v);
                ICTabla.setModel(modelo);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexion" + e.getMessage(), "Error de Conexion", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void CargarDatosActivos() throws SQLException {
        System.out.println("cargar datos activos");
        DefaultTableModel modelo = (DefaultTableModel) ICTabla.getModel();
        modelo.setRowCount(0);
        res = Conector.Consulta("select CI,Nombre,Apellido,TipodePago,Valor,Celular,Telefono,Direccion,Control,Observaciones from Clientes where Estado='ACTIVO'");

        try {
            while (res.next()) {
                Vector v = new Vector();
                v.add(res.getString(1));
                v.add(res.getString(2));
                v.add(res.getString(3));
                v.add(res.getString(4));
                v.add(res.getDouble(5));
                v.add(res.getString(6));
                v.add(res.getString(7));
                v.add(res.getString(8));
                v.add(res.getString(9));
                v.add(res.getString(10));
                modelo.addRow(v);
                ICTabla.setModel(modelo);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexion" + e.getMessage(), "Error de Conexion", JOptionPane.ERROR_MESSAGE);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        PClientes = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        BAgregarClientes = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        ICTabla = new javax.swing.JTable();
        Filtro = new javax.swing.JComboBox<>();
        BEliminar = new javax.swing.JButton();
        BModificar = new javax.swing.JButton();
        JTBuscar = new javax.swing.JTextField();
        Fondo1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        BAgregarClientes.setText("Agregar Clientes");
        BAgregarClientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BAgregarClientesActionPerformed(evt);
            }
        });
        jPanel1.add(BAgregarClientes, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 190, -1, -1));

        ICTabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "CI", "Nombre", "Apellido", "Tipo de pago", "Valor", "Celular", "Telefono", "Direccion", "Control", "Observaciones"
            }
        ));
        jScrollPane1.setViewportView(ICTabla);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 44, 966, 109));

        Filtro.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Activos", "Eliminados", "Todos" }));
        Filtro.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                FiltroItemStateChanged(evt);
            }
        });
        Filtro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FiltroActionPerformed(evt);
            }
        });
        jPanel1.add(Filtro, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 16, 169, -1));

        BEliminar.setText("Eliminar");
        BEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BEliminarActionPerformed(evt);
            }
        });
        jPanel1.add(BEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(189, 189, 97, -1));

        BModificar.setText("Modificar");
        BModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BModificarActionPerformed(evt);
            }
        });
        jPanel1.add(BModificar, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 189, 142, -1));

        JTBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                JTBuscarKeyReleased(evt);
            }
        });
        jPanel1.add(JTBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 10, 130, -1));

        Fondo1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/PantallaPri.jpg"))); // NOI18N
        jPanel1.add(Fondo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1080, -1));

        PClientes.addTab("Clientes", jPanel1);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 994, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 251, Short.MAX_VALUE)
        );

        PClientes.addTab("Calendario", jPanel2);

        jMenu1.setText("Inicio");
        jMenuBar1.add(jMenu1);

        jMenu2.setText("Ayuda");
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(PClientes, javax.swing.GroupLayout.PREFERRED_SIZE, 999, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(PClientes, javax.swing.GroupLayout.PREFERRED_SIZE, 279, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BModificarActionPerformed

        System.out.println("modificar datos");
        try {
            int filsel = ICTabla.getSelectedRow();
            String num = ICTabla.getValueAt(filsel, 0).toString();
            if (filsel == -1) {
                JOptionPane.showMessageDialog(null, "Debes seleccionar el cliente a eliminar", "Advertencia", JOptionPane.WARNING_MESSAGE);
            } else {

                MClientes abrir;
                try {
                    abrir = new MClientes(num);
                    abrir.setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(Interfaces.class.getName()).log(Level.SEVERE, null, ex);

                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Seleccione el cliente a modificar");
        }
        /**/
    }//GEN-LAST:event_BModificarActionPerformed

    private void BEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BEliminarActionPerformed
        System.out.println("Eliminar datos");
        Connection cn = Conector.getConexion();
        int filsel;
        int resp;

        try {
            filsel = ICTabla.getSelectedRow();
            if (filsel == -1) {
                JOptionPane.showMessageDialog(null, "Debes seleccionar el cliente a eliminar", "Advertencia", JOptionPane.WARNING_MESSAGE);
            } else {
                resp = JOptionPane.showConfirmDialog(null, "¿Esta seguro de eliminar este cliente?", "Eliminar", JOptionPane.YES_NO_OPTION);
                if (resp == JOptionPane.YES_OPTION) {

                    PreparedStatement pps = cn.prepareStatement("update Clientes set Estado='ELIMINADO' where ci=?");
                    pps.setString(1, ICTabla.getValueAt(filsel, 0).toString());
                    JOptionPane.showMessageDialog(null, "Cliente Eliminado");
                    int resp2 = pps.executeUpdate();
                    if (resp2 < 0) {
                        JOptionPane.showMessageDialog(null, "Error al ingresar");
                    }
                }
            }
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, "No se pudo eliminar el cliente");
        }
    }//GEN-LAST:event_BEliminarActionPerformed

    private void FiltroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FiltroActionPerformed
        System.out.println("Filtros");
        if (Filtro.getSelectedItem().toString() == "Todos") {
            try {
                CargarDatos();
            } catch (SQLException ex) {
                Logger.getLogger(Interfaces.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if (Filtro.getSelectedItem().toString() == "Eliminados") {
            try {
                CargarDatosEliminados();
            } catch (SQLException ex) {
                Logger.getLogger(Interfaces.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if (Filtro.getSelectedItem().toString() == "Activos") {
            try {
                CargarDatosActivos();
            } catch (SQLException ex) {
                Logger.getLogger(Interfaces.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_FiltroActionPerformed

    private void BAgregarClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BAgregarClientesActionPerformed
        System.out.println("Agregar clientes");
        AClientes abrir = new AClientes();
        abrir.setVisible(true);
    }//GEN-LAST:event_BAgregarClientesActionPerformed

    private void JTBuscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_JTBuscarKeyReleased
        buscar();
    }//GEN-LAST:event_JTBuscarKeyReleased

    private void FiltroItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_FiltroItemStateChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_FiltroItemStateChanged

    public static void main(String args[]) {
        System.out.println("MAin");
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                System.out.println("for main");
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Interfaces.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Interfaces.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Interfaces.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Interfaces.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new Interfaces().setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(Interfaces.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BAgregarClientes;
    private javax.swing.JButton BEliminar;
    private javax.swing.JButton BModificar;
    private javax.swing.JComboBox<String> Filtro;
    private javax.swing.JLabel Fondo1;
    private javax.swing.JTable ICTabla;
    private javax.swing.JTextField JTBuscar;
    private javax.swing.JTabbedPane PClientes;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables

    private void buscar() {
        DefaultTableModel modelo = (DefaultTableModel) ICTabla.getModel();
        modelo.setRowCount(0);
        String buscar=JTBuscar.getText();
        res = Conector.Consulta("select CI,Nombre,Apellido,TipodePago,Valor,Celular,Telefono,Direccion,Control,Observaciones from Clientes where Apellido like '"+buscar+"%'"+" or Nombre like '"+buscar+"%'");

        try {
            while (res.next()) {
                Vector v = new Vector();
                v.add(res.getString(1));
                v.add(res.getString(2));
                v.add(res.getString(3));
                v.add(res.getString(4));
                v.add(res.getDouble(5));
                v.add(res.getString(6));
                v.add(res.getString(7));
                v.add(res.getString(8));
                v.add(res.getString(9));
                v.add(res.getString(10));
                modelo.addRow(v);
                ICTabla.setModel(modelo);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexion" + e.getMessage(), "Error de Conexion", JOptionPane.ERROR_MESSAGE);
        }
    }
}
